module buzzer_ctrl (
    input  logic clk,
    input  logic rstN,
    input  logic success_pulse,
    input  logic wrong_pulse,
    output logic buzzer
);

    localparam int unsigned BEEP_ON_MS = 200;
    localparam int unsigned BEEP_GAP_MS = 100;

    typedef enum logic [2:0] {
        S_IDLE,
        S_ON1,
        S_GAP,
        S_ON2,
        S_END
    } state_t;

    state_t       st;
    logic [9:0]   cnt;
    logic         two_beeps;

    always_ff @(posedge clk or negedge rstN) begin
        if (!rstN) begin
            st        <= S_IDLE;
            cnt       <= 10'd0;
            two_beeps <= 1'b0;
        end else begin
            unique case (st)
                S_IDLE: begin
                    cnt <= 10'd0;
                    if (wrong_pulse) begin
                        st        <= S_ON1;
                        two_beeps <= 1'b1;
                    end else if (success_pulse) begin
                        st        <= S_ON1;
                        two_beeps <= 1'b0;
                    end
                end
                S_ON1: begin
                    if (cnt + 10'd1 >= BEEP_ON_MS[9:0]) begin
                        cnt <= 10'd0;
                        st  <= two_beeps ? S_GAP : S_END;
                    end else begin
                        cnt <= cnt + 10'd1;
                    end
                end
                S_GAP: begin
                    if (cnt + 10'd1 >= BEEP_GAP_MS[9:0]) begin
                        cnt <= 10'd0;
                        st  <= S_ON2;
                    end else begin
                        cnt <= cnt + 10'd1;
                    end
                end
                S_ON2: begin
                    if (cnt + 10'd1 >= BEEP_ON_MS[9:0]) begin
                        cnt <= 10'd0;
                        st  <= S_END;
                    end else begin
                        cnt <= cnt + 10'd1;
                    end
                end
                S_END: begin
                    st <= S_IDLE;
                end
                default: st <= S_IDLE;
            endcase
        end
    end

    assign buzzer = (st == S_ON1) || (st == S_ON2);

endmodule
