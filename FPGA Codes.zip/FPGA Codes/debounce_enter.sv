module debounce_enter (
    input  logic clk,
    input  logic rstN,
    input  logic btn,
    input  logic done,
    output logic timer_en,
    output logic enter_p
);

    typedef enum logic [2:0] {s0, s1, s2, s3, s4} state_t;

    state_t s_reg, s_next;

    always_ff @(posedge clk or negedge rstN) begin
        if (!rstN)
            s_reg <= s0;
        else
            s_reg <= s_next;
    end

    always_comb begin
        s_next   = s_reg;
        timer_en = '0;
        enter_p  = '0;

        case (s_reg)
            s0: begin
                if (!btn)
                    s_next = s1;
            end
            s1: begin
                timer_en = '1;
                if (done) begin
                    if (btn) s_next = s0;
                    else     s_next = s2;
                end
            end
            s2: begin
                enter_p = '1;
                s_next  = s3;
            end
            s3: begin
                if (btn)
                    s_next = s4;
            end
            s4: begin
                timer_en = '1;
                if (done)
                    s_next = s0;
            end
        endcase
    end

endmodule
