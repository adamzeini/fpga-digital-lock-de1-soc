module pwd_change_ctrl (
    input  logic       clk,
    input  logic       rstN,
    input  logic       sw_change,
    input  logic       y,
    input  logic       enter_p,
    input  logic [3:0] digit_in,
    input  logic       supervisor_reset,

    output logic [3:0] wr_addr,
    output logic [3:0] wr_data,
    output logic       wren,

    output logic       change_active,
    output logic       change_confirm,
    output logic       change_mismatch,
    output logic       change_done
);

    typedef enum logic [2:0] {
        S_IDLE,
        S_ARMED,
        S_CAPTURE_FIRST,
        S_CONFIRM,
        S_MISMATCH,
        S_COMMIT,
        S_DONE
    } state_t;

    localparam logic [10:0] MISMATCH_HOLD_MS = 11'd2000;

    state_t      s_reg, s_next;
    logic [2:0]  dig_cnt, dig_cnt_next;
    logic [2:0]  wr_cnt,  wr_cnt_next;
    logic [10:0] mismatch_cnt, mismatch_cnt_next;

    logic [3:0]  buf0, buf1, buf2, buf3;
    logic        confirm_match;
    logic        current_digit_match;

    always_comb begin
        case (dig_cnt)
            3'd0:    current_digit_match = (digit_in == buf0);
            3'd1:    current_digit_match = (digit_in == buf1);
            3'd2:    current_digit_match = (digit_in == buf2);
            3'd3:    current_digit_match = (digit_in == buf3);
            default: current_digit_match = 1'b0;
        endcase
    end

    always_ff @(posedge clk or negedge rstN) begin
        if (!rstN) begin
            s_reg        <= S_IDLE;
            dig_cnt      <= 3'd0;
            wr_cnt       <= 3'd0;
            mismatch_cnt <= 11'd0;
            confirm_match <= 1'b1;
            buf0         <= 4'd0;
            buf1         <= 4'd0;
            buf2         <= 4'd0;
            buf3         <= 4'd0;
        end else begin
            s_reg        <= s_next;
            dig_cnt      <= dig_cnt_next;
            wr_cnt       <= wr_cnt_next;
            mismatch_cnt <= mismatch_cnt_next;

            if ((s_reg != S_CONFIRM) && (s_next == S_CONFIRM))
                confirm_match <= 1'b1;
            else if ((s_reg == S_CONFIRM) && enter_p)
                confirm_match <= confirm_match & current_digit_match;

            if ((s_reg == S_CAPTURE_FIRST) && enter_p) begin
                case (dig_cnt)
                    3'd0: buf0 <= digit_in;
                    3'd1: buf1 <= digit_in;
                    3'd2: buf2 <= digit_in;
                    3'd3: buf3 <= digit_in;
                    default: ;
                endcase
            end
        end
    end

    always_comb begin
        s_next           = s_reg;
        dig_cnt_next     = dig_cnt;
        wr_cnt_next      = wr_cnt;
        mismatch_cnt_next = mismatch_cnt;

        wren             = 1'b0;
        wr_addr          = 4'd0;
        wr_data          = 4'd0;
        change_active    = 1'b0;
        change_confirm   = 1'b0;
        change_mismatch  = 1'b0;
        change_done      = 1'b0;

        case (s_reg)

            S_IDLE: begin
                dig_cnt_next      = 3'd0;
                wr_cnt_next       = 3'd0;
                mismatch_cnt_next = 11'd0;
                if (sw_change)
                    s_next = S_ARMED;
            end

            S_ARMED: begin
                dig_cnt_next = 3'd0;
                if (!sw_change || supervisor_reset)
                    s_next = S_IDLE;
                else if (y)
                    s_next = S_CAPTURE_FIRST;
            end

            S_CAPTURE_FIRST: begin
                change_active = 1'b1;
                if (!sw_change || supervisor_reset) begin
                    s_next = S_IDLE;
                end else if (enter_p) begin
                    if (dig_cnt == 3'd3) begin
                        s_next       = S_CONFIRM;
                        dig_cnt_next = 3'd0;
                    end else begin
                        dig_cnt_next = dig_cnt + 3'd1;
                    end
                end
            end

            S_CONFIRM: begin
                change_active  = 1'b1;
                change_confirm = 1'b1;
                if (!sw_change || supervisor_reset) begin
                    s_next = S_IDLE;
                end else if (enter_p) begin
                    if (dig_cnt == 3'd3) begin
                        dig_cnt_next = 3'd0;
                        if (confirm_match && current_digit_match) begin
                            s_next      = S_COMMIT;
                            wr_cnt_next = 3'd0;
                        end else begin
                            s_next            = S_MISMATCH;
                            mismatch_cnt_next = 11'd0;
                        end
                    end else begin
                        dig_cnt_next = dig_cnt + 3'd1;
                    end
                end
            end

            S_MISMATCH: begin
                change_active   = 1'b1;
                change_mismatch = 1'b1;
                if (!sw_change || supervisor_reset) begin
                    s_next = S_IDLE;
                end else if (mismatch_cnt + 11'd1 >= MISMATCH_HOLD_MS) begin
                    s_next            = S_CAPTURE_FIRST;
                    dig_cnt_next      = 3'd0;
                    mismatch_cnt_next = 11'd0;
                end else begin
                    mismatch_cnt_next = mismatch_cnt + 11'd1;
                end
            end

            S_COMMIT: begin
                wren    = 1'b1;
                wr_addr = {2'd0, wr_cnt[1:0]};
                case (wr_cnt)
                    3'd0:    wr_data = buf0;
                    3'd1:    wr_data = buf1;
                    3'd2:    wr_data = buf2;
                    3'd3:    wr_data = buf3;
                    default: wr_data = 4'd0;
                endcase
                if (wr_cnt == 3'd3) begin
                    s_next      = S_DONE;
                    wr_cnt_next = 3'd0;
                end else begin
                    wr_cnt_next = wr_cnt + 3'd1;
                end
            end

            S_DONE: begin
                change_done = 1'b1;
                if (!sw_change || supervisor_reset)
                    s_next = S_IDLE;
            end

            default: s_next = S_IDLE;

        endcase
    end

endmodule
