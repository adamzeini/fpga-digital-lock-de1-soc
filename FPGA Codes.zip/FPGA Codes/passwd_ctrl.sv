module passwd_ctrl (
    input  logic       clk,
    input  logic       rstN,
    input  logic [3:0] digit_in,
    input  logic       enter_p,
    input  logic [3:0] q,
    output logic       check,
    output logic       enter_p_d
);

    logic [3:0] digit_in_r;
    logic       enter_p_r;

    always_ff @(posedge clk or negedge rstN) begin
        if (!rstN) begin
            digit_in_r <= '0;
            enter_p_r  <= '0;
        end else begin
            enter_p_r <= enter_p;
            if (enter_p)
                digit_in_r <= digit_in;
        end
    end

    assign check     = (q == digit_in_r) ? '1 : '0;
    assign enter_p_d = enter_p_r;

endmodule
