module timer_short (
    input  logic clk,
    input  logic rstN,
    input  logic start,
    output logic done
);

    logic [4:0] t_reg, t_next;

    always_ff @(posedge clk or negedge rstN) begin
        if (!rstN)
            t_reg <= '0;
        else
            t_reg <= t_next;
    end

    assign t_next = start ? (t_reg + 5'd1) : '0;
    assign done   = (t_reg =='1) ? '1 : '0;

endmodule
