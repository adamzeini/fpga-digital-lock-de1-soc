module addr_counter (
    input  logic       clk,
    input  logic       rstN,
    input  logic       mode,
    input  logic       enter_p,
    input  logic       clr,
    output logic [3:0] addr
);

    logic [3:0] cnt;

    always_ff @(posedge clk or negedge rstN) begin
        if (!rstN)        cnt <= 4'd0;
        else if (clr)     cnt <= 4'd0;
        else if (enter_p) cnt <= cnt + 4'd1;
    end

    always_comb begin
        if (mode) addr = cnt + 4'd8;
        else      addr = cnt;
    end

endmodule
