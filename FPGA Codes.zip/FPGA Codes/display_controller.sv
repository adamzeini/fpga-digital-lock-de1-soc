module display_controller (
    input  logic       clk,
    input  logic       rstN,
    input  logic       clr,
    input  logic       enter_p,
    input  logic [3:0] digit_in,

    input  logic       y,
    input  logic       err,
    input  logic       locked,
    input  logic       change_active,
    input  logic       change_confirm,
    input  logic       change_mismatch,
    input  logic       change_done,

    output logic [6:0] HEX0,
    output logic [6:0] HEX1,
    output logic [6:0] HEX2,
    output logic [6:0] HEX3,
    output logic [6:0] HEX4,
    output logic [6:0] HEX5
);

    localparam logic [6:0] BLANK = 7'h7F;
    localparam logic [6:0] CH_O  = 7'h40;
    localparam logic [6:0] CH_P  = 7'h0C;
    localparam logic [6:0] CH_E  = 7'h06;
    localparam logic [6:0] CH_r  = 7'h2F;
    localparam logic [6:0] CH_L  = 7'h47;
    localparam logic [6:0] CH_C  = 7'h46;
    localparam logic [6:0] CH_H  = 7'h09;
    localparam logic [6:0] CH_d  = 7'h21;

    logic change_active_d;
    logic change_confirm_d;
    logic change_mismatch_d;
    always_ff @(posedge clk or negedge rstN) begin
        if (!rstN) begin
            change_active_d   <= 1'b0;
            change_confirm_d  <= 1'b0;
            change_mismatch_d <= 1'b0;
        end
        else begin
            change_active_d   <= change_active;
            change_confirm_d  <= change_confirm;
            change_mismatch_d <= change_mismatch;
        end
    end
    wire change_active_rise   = change_active && !change_active_d;
    wire change_confirm_rise  = change_confirm && !change_confirm_d;
    wire change_confirm_fall  = !change_confirm && change_confirm_d;
    wire change_mismatch_rise = change_mismatch && !change_mismatch_d;
    wire buffer_clr           = clr || change_active_rise
                              || change_confirm_rise
                              || change_confirm_fall
                              || change_mismatch_rise
                              || change_done;
    wire accept_digit         = enter_p && !change_mismatch && !change_done;

    logic [3:0] dig0, dig1, dig2, dig3;
    logic       v0, v1, v2, v3;
    logic [1:0] pos;
    logic       four_done;

    always_ff @(posedge clk or negedge rstN) begin
        if (!rstN) begin
            dig0 <= 4'h0; dig1 <= 4'h0; dig2 <= 4'h0; dig3 <= 4'h0;
            v0   <= 1'b0; v1   <= 1'b0; v2   <= 1'b0; v3   <= 1'b0;
            pos  <= 2'd0;
            four_done <= 1'b0;
        end
        else if (buffer_clr) begin
            dig0 <= 4'h0; dig1 <= 4'h0; dig2 <= 4'h0; dig3 <= 4'h0;
            v0   <= 1'b0; v1   <= 1'b0; v2   <= 1'b0; v3   <= 1'b0;
            pos  <= 2'd0;
            four_done <= 1'b0;
        end
        else if (accept_digit) begin
            case (pos)
                2'd0: begin dig0 <= digit_in; v0 <= 1'b1; end
                2'd1: begin dig1 <= digit_in; v1 <= 1'b1; end
                2'd2: begin dig2 <= digit_in; v2 <= 1'b1; end
                2'd3: begin dig3 <= digit_in; v3 <= 1'b1;
                            four_done <= 1'b1;
                      end
                default: ;
            endcase
            pos <= pos + 2'd1;
        end
    end

    logic [6:0] seg_d0, seg_d1, seg_d2, seg_d3;

    seg7 u_d0 (.hex(dig0), .seg(seg_d0));
    seg7 u_d1 (.hex(dig1), .seg(seg_d1));
    seg7 u_d2 (.hex(dig2), .seg(seg_d2));
    seg7 u_d3 (.hex(dig3), .seg(seg_d3));

    assign HEX5 = v0 ? seg_d0 : BLANK;
    assign HEX4 = v1 ? seg_d1 : BLANK;
    assign HEX3 = v2 ? seg_d2 : BLANK;
    assign HEX2 = v3 ? seg_d3 : BLANK;

    logic _y_unused;
    assign _y_unused = y;

    logic success_steady;
    assign success_steady = four_done & ~err & ~locked
                          & ~change_active & ~change_done;

    always_comb begin
        if (locked) begin
            HEX1 = CH_L;
            HEX0 = CH_O;
        end
        else if (change_mismatch) begin
            HEX1 = CH_E;
            HEX0 = CH_r;
        end
        else if (change_done) begin
            HEX1 = BLANK;
            HEX0 = BLANK;
        end
        else if (change_active) begin
            HEX1 = CH_C;
            HEX0 = CH_H;
        end
        else if (err) begin
            HEX1 = CH_E;
            HEX0 = CH_r;
        end
        else if (success_steady) begin
            HEX1 = CH_O;
            HEX0 = CH_P;
        end
        else begin
            HEX1 = BLANK;
            HEX0 = BLANK;
        end
    end

endmodule


module seg7 (
    input  logic [3:0] hex,
    output logic [6:0] seg
);
    always_comb begin
        case (hex)
            4'h0: seg = 7'h40;
            4'h1: seg = 7'h79;
            4'h2: seg = 7'h24;
            4'h3: seg = 7'h30;
            4'h4: seg = 7'h19;
            4'h5: seg = 7'h12;
            4'h6: seg = 7'h02;
            4'h7: seg = 7'h78;
            4'h8: seg = 7'h00;
            4'h9: seg = 7'h10;
            4'hA: seg = 7'h08;
            4'hB: seg = 7'h03;
            4'hC: seg = 7'h46;
            4'hD: seg = 7'h21;
            4'hE: seg = 7'h06;
            4'hF: seg = 7'h0E;
            default: seg = 7'h7F;
        endcase
    end
endmodule
