module lock_top (
    input  logic       CLOCK_50,
    input  logic       KEY_reset,
    input  logic       SW_mode,
    input  logic       SW_change,
    input  logic       supervisor_reset,

    input  logic [3:0] KEYPAD_ROW,
    output logic [3:0] KEYPAD_COL,

    output logic       LED_correct,
    output logic       LED_error,
    output logic       LED_locked,
    output logic       LED_change_mode,
    output logic       LED_change_done,

    output logic [6:0] HEX0,
    output logic [6:0] HEX1,
    output logic [6:0] HEX2,
    output logic [6:0] HEX3,
    output logic [6:0] HEX4,
    output logic [6:0] HEX5,

    output logic       LCD_RS,
    output logic       LCD_RW,
    output logic       LCD_E,
    output logic [3:0] LCD_D,

    output logic       BUZZER,

    output logic       SERVO_PWM
);

    logic        clk_1ms;
    logic        rst_n;
    logic        sup_reset_h;

    logic        debounce_timer_en;
    logic        debounce_done;
    logic        enter_p_raw;
    logic        enter_p_gated;

    logic        session_start;
    logic        error_left;

    logic [3:0]  addr;
    logic [3:0]  q;

    logic        check;
    logic        enter_p_d;

    logic        y;
    logic        clr;
    logic        locked;
    logic        err;
    logic        in_login;
    logic [2:0]  tries_left;
    logic        correct_pulse;
    logic        wrong_pulse;

    logic [3:0]  wr_addr;
    logic [3:0]  wr_data;
    logic        wren;

    logic        cnt_mode;

    logic        change_active;
    logic        change_confirm;
    logic        change_mismatch;
    logic        change_done;

    logic [3:0]  digit_in;
    logic        key_enter_kp;
    logic        key_enter_meta;
    logic        key_enter_sync;

    assign rst_n       = KEY_reset;
    assign sup_reset_h = ~supervisor_reset;
    assign cnt_mode    = SW_mode | SW_change;

    assign enter_p_gated = enter_p_raw & ~change_active & ~change_done;

    keypad_interface u_keypad (
        .clk   (CLOCK_50),
        .rstn  (rst_n),
        .rows  (KEYPAD_ROW),
        .cols  (KEYPAD_COL),
        .pass  (digit_in),
        .Enter (key_enter_kp)
    );

    clock_divider u_clk (
        .system_clk_50mhz (CLOCK_50),
        .reset            (~rst_n),
        .clock_1ms        (clk_1ms)
    );

    always_ff @(posedge clk_1ms or negedge rst_n) begin
        if (!rst_n) begin
            key_enter_meta <= 1'b1;
            key_enter_sync <= 1'b1;
        end
        else begin
            key_enter_meta <= key_enter_kp;
            key_enter_sync <= key_enter_meta;
        end
    end

    timer_short u_dbtimer (
        .clk   (clk_1ms),
        .rstN  (rst_n),
        .start (debounce_timer_en),
        .done  (debounce_done)
    );

    debounce_enter u_deb (
        .clk      (clk_1ms),
        .rstN     (rst_n),
        .btn      (key_enter_sync),
        .done     (debounce_done),
        .timer_en (debounce_timer_en),
        .enter_p  (enter_p_raw)
    );

    timer_long u_timer (
        .clk        (clk_1ms),
        .rstN       (rst_n),
        .start      (session_start),
        .error_left (error_left)
    );

    addr_counter u_counter (
        .clk     (clk_1ms),
        .rstN    (rst_n),
        .mode    (cnt_mode),
        .enter_p (enter_p_gated),
        .clr     (clr),
        .addr    (addr)
    );

    passwd_store u_store (
        .clk       (clk_1ms),
        .rdaddress (addr),
        .wraddress (wr_addr),
        .data      (wr_data),
        .wren      (wren),
        .q         (q)
    );

    passwd_ctrl u_ctrl (
        .clk       (clk_1ms),
        .rstN      (rst_n),
        .digit_in  (digit_in),
        .enter_p   (enter_p_gated),
        .q         (q),
        .check     (check),
        .enter_p_d (enter_p_d)
    );

    pass_check u_fsm (
        .clk           (clk_1ms),
        .rstN          (rst_n),
        .reset         (sup_reset_h),
        .enter_p       (enter_p_d),
        .check         (check),
        .error_left    (error_left),
        .y             (y),
        .start         (session_start),
        .clr           (clr),
        .locked        (locked),
        .err           (err),
        .in_login      (in_login),
        .tries_left    (tries_left),
        .correct_pulse (correct_pulse),
        .wrong_pulse   (wrong_pulse)
    );

    pwd_change_ctrl u_change (
        .clk              (clk_1ms),
        .rstN             (rst_n),
        .sw_change        (SW_change),
        .y                (y),
        .enter_p          (enter_p_raw),
        .digit_in         (digit_in),
        .supervisor_reset (sup_reset_h),
        .wr_addr          (wr_addr),
        .wr_data          (wr_data),
        .wren             (wren),
        .change_active    (change_active),
        .change_confirm   (change_confirm),
        .change_mismatch  (change_mismatch),
        .change_done      (change_done)
    );

    display_controller u_disp (
        .clk           (clk_1ms),
        .rstN          (rst_n),
        .clr           (clr),
        .enter_p       (enter_p_raw),
        .digit_in      (digit_in),
        .y             (y),
        .err           (err),
        .locked        (locked),
        .change_active (change_active),
        .change_confirm(change_confirm),
        .change_mismatch(change_mismatch),
        .change_done   (change_done),
        .HEX0          (HEX0),
        .HEX1          (HEX1),
        .HEX2          (HEX2),
        .HEX3          (HEX3),
        .HEX4          (HEX4),
        .HEX5          (HEX5)
    );

    localparam logic [3:0] ST_WELCOME     = 4'd0;
    localparam logic [3:0] ST_SUPERVISOR  = 4'd1;
    localparam logic [3:0] ST_WRONG       = 4'd2;
    localparam logic [3:0] ST_LOCKED      = 4'd3;
    localparam logic [3:0] ST_CORRECT     = 4'd4;
    localparam logic [3:0] ST_CHANGE_AUTH = 4'd5;
    localparam logic [3:0] ST_CHANGE_NEW  = 4'd6;
    localparam logic [3:0] ST_CHANGE_DONE = 4'd7;
    localparam logic [3:0] ST_CHANGE_CONFIRM  = 4'd8;
    localparam logic [3:0] ST_CHANGE_MISMATCH = 4'd9;

    logic [3:0] sys_state;

    always_comb begin
        if (locked)             sys_state = ST_LOCKED;
        else if (change_done)   sys_state = ST_CHANGE_DONE;
        else if (change_mismatch) sys_state = ST_CHANGE_MISMATCH;
        else if (change_confirm)  sys_state = ST_CHANGE_CONFIRM;
        else if (change_active) sys_state = ST_CHANGE_NEW;
        else if (in_login)      sys_state = ST_CORRECT;
        else if (err)           sys_state = ST_WRONG;
        else if (SW_change)     sys_state = ST_CHANGE_AUTH;
        else if (SW_mode)       sys_state = ST_SUPERVISOR;
        else                    sys_state = ST_WELCOME;
    end

    lcd_controller u_lcd (
        .clk       (clk_1ms),
        .rstN      (rst_n),
        .sys_state (sys_state),
        .tries_left(tries_left),
        .LCD_RS    (LCD_RS),
        .LCD_RW    (LCD_RW),
        .LCD_E     (LCD_E),
        .LCD_D     (LCD_D)
    );

    buzzer_ctrl u_buzz (
        .clk           (clk_1ms),
        .rstN          (rst_n),
        .success_pulse (correct_pulse),
        .wrong_pulse   (wrong_pulse),
        .buzzer        (BUZZER)
    );

    servo_ctrl u_servo (
        .clk_50mhz     (CLOCK_50),
        .rstN          (rst_n),
        .correct_pulse (correct_pulse),
        .SERVO_PWM     (SERVO_PWM)
    );

    assign LED_correct     = y;
    assign LED_error       = err;
    assign LED_locked      = locked;
    assign LED_change_mode = change_active;
    assign LED_change_done = change_done;

endmodule
