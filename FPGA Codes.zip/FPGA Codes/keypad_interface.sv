module keypad_interface #(
    parameter int unsigned CLK_FREQ_HZ  = 50_000_000,
    parameter int unsigned SCAN_RATE_HZ = 1_000,
    parameter int unsigned DEBOUNCE_MS  = 20
) (
    input  logic       clk,
    input  logic       rstn,
    input  logic [3:0] rows,
    output logic [3:0] cols,
    output logic [3:0] pass,
    output logic       Enter
);

    localparam int unsigned SCAN_DIVISOR_RAW =
        (SCAN_RATE_HZ == 0) ? CLK_FREQ_HZ : (CLK_FREQ_HZ / SCAN_RATE_HZ);
    localparam int unsigned SCAN_DIVISOR =
        (SCAN_DIVISOR_RAW < 1) ? 1 : SCAN_DIVISOR_RAW;
    localparam int unsigned SCAN_CNT_W =
        (SCAN_DIVISOR <= 2) ? 1 : $clog2(SCAN_DIVISOR);

    localparam int unsigned DEBOUNCE_TICKS_RAW =
        (SCAN_RATE_HZ * DEBOUNCE_MS) / 1000;
    localparam int unsigned DEBOUNCE_TICKS =
        (DEBOUNCE_TICKS_RAW < 1) ? 1 : DEBOUNCE_TICKS_RAW;
    localparam int unsigned DEBOUNCE_W =
        (DEBOUNCE_TICKS <= 2) ? 1 : $clog2(DEBOUNCE_TICKS);

    typedef enum logic [1:0] {
        S_SCAN,
        S_DB_PRESS,
        S_PRESSED,
        S_DB_RELEASE
    } state_t;

    state_t state;

    logic [3:0] rows_meta, rows_sync;
    logic [3:0] row_latch, col_latch;
    logic [1:0] scan_col;
    logic [SCAN_CNT_W-1:0] scan_cnt;
    logic [DEBOUNCE_W-1:0] db_cnt;
    logic scan_tick;

    function automatic logic [3:0] col_pattern(input logic [1:0] idx);
        col_pattern = ~(4'b0001 << idx);
    endfunction

    function automatic logic single_key_pressed(input logic [3:0] al_rows);
        case (al_rows)
            4'b1110,
            4'b1101,
            4'b1011,
            4'b0111: single_key_pressed = 1'b1;
            default: single_key_pressed = 1'b0;
        endcase
    endfunction

    function automatic [1:0] encode4(input [3:0] al_onehot);
        casez (~al_onehot)
            4'b???1: encode4 = 2'd0;
            4'b??10: encode4 = 2'd1;
            4'b?100: encode4 = 2'd2;
            4'b1000: encode4 = 2'd3;
            default: encode4 = 2'd0;
        endcase
    endfunction

    function automatic [3:0] decode_key(input [1:0] r, input [1:0] c);
        case ({r, c})
            4'hF: decode_key = 4'h1;
            4'hE: decode_key = 4'h2;
            4'hD: decode_key = 4'h3;
            4'hC: decode_key = 4'hA;
            4'hB: decode_key = 4'h4;
            4'hA: decode_key = 4'h5;
            4'h9: decode_key = 4'h6;
            4'h8: decode_key = 4'hB;
            4'h7: decode_key = 4'h7;
            4'h6: decode_key = 4'h8;
            4'h5: decode_key = 4'h9;
            4'h4: decode_key = 4'hC;
            4'h3: decode_key = 4'hE;
            4'h2: decode_key = 4'h0;
            4'h1: decode_key = 4'hF;
            default: decode_key = 4'hD;
        endcase
    endfunction

    always_comb begin
        cols = col_pattern(scan_col);
    end

    always_ff @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            rows_meta <= 4'hF;
            rows_sync <= 4'hF;
        end
        else begin
            rows_meta <= rows;
            rows_sync <= rows_meta;
        end
    end

    always_ff @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            scan_cnt  <= '0;
            scan_tick <= 1'b0;
        end
        else if (scan_cnt == SCAN_DIVISOR - 1) begin
            scan_cnt  <= '0;
            scan_tick <= 1'b1;
        end
        else begin
            scan_cnt  <= scan_cnt + 1'b1;
            scan_tick <= 1'b0;
        end
    end

    always_ff @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            state     <= S_SCAN;
            scan_col  <= 2'd0;
            row_latch <= 4'hF;
            col_latch <= 4'hF;
            db_cnt    <= '0;
            pass      <= 4'h0;
            Enter     <= 1'b1;
        end
        else begin
            state     <= state;
            scan_col  <= scan_col;
            row_latch <= row_latch;
            col_latch <= col_latch;
            db_cnt    <= db_cnt;
            pass      <= pass;
            Enter     <= Enter;

            if (scan_tick) begin
                case (state)
                    S_SCAN: begin
                        Enter  <= 1'b1;
                        db_cnt <= '0;
                        if (single_key_pressed(rows_sync)) begin
                            row_latch <= rows_sync;
                            col_latch <= col_pattern(scan_col);
                            state     <= S_DB_PRESS;
                        end
                        else begin
                            scan_col <= scan_col + 2'd1;
                        end
                    end
                    S_DB_PRESS: begin
                        if (!single_key_pressed(rows_sync) || (rows_sync != row_latch)) begin
                            state  <= S_SCAN;
                            db_cnt <= '0;
                        end
                        else if (db_cnt == DEBOUNCE_TICKS - 1) begin
                            pass  <= decode_key(encode4(row_latch), encode4(col_latch));
                            Enter <= 1'b0;
                            state <= S_PRESSED;
                        end
                        else begin
                            db_cnt <= db_cnt + 1'b1;
                        end
                    end
                    S_PRESSED: begin
                        if (&rows_sync) begin
                            db_cnt <= '0;
                            state  <= S_DB_RELEASE;
                        end
                    end
                    S_DB_RELEASE: begin
                        if (!(&rows_sync)) begin
                            state  <= S_PRESSED;
                            db_cnt <= '0;
                        end
                        else if (db_cnt == DEBOUNCE_TICKS - 1) begin
                            Enter    <= 1'b1;
                            scan_col <= scan_col + 2'd1;
                            db_cnt   <= '0;
                            state    <= S_SCAN;
                        end
                        else begin
                            db_cnt <= db_cnt + 1'b1;
                        end
                    end
                    default: begin
                        state <= S_SCAN;
                    end
                endcase
            end
        end
    end
endmodule
