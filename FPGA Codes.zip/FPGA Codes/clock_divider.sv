module clock_divider (
    input  logic system_clk_50mhz,
    input  logic reset,
    output logic clock_1ms
);

    localparam int PERIOD  = 50_000;
    localparam int HALF    = PERIOD / 2;

    logic [15:0] ctr_reg;

    always_ff @(posedge system_clk_50mhz) begin
        if (reset) begin
            ctr_reg   <= 16'd0;
            clock_1ms <= 1'b0;
        end else begin
            if (ctr_reg == PERIOD - 1) begin
                ctr_reg   <= 16'd0;
                clock_1ms <= 1'b0;
            end else begin
                ctr_reg <= ctr_reg + 16'd1;
                if (ctr_reg == HALF - 1)
                    clock_1ms <= 1'b1;
            end
        end
    end

endmodule
