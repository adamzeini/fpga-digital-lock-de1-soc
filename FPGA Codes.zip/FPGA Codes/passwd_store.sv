module passwd_store (
    input  logic       clk,
    input  logic [3:0] rdaddress,
    input  logic [3:0] wraddress,
    input  logic [3:0] data,
    input  logic       wren,
    output logic [3:0] q
);

    RF1 u_rf (
        .clock     (clk),
        .rdaddress (rdaddress),
        .wraddress (wraddress),
        .data      (data),
        .wren      (wren),
        .q         (q)
    );

endmodule
