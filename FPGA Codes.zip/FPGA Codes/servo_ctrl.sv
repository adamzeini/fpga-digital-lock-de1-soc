module servo_ctrl (
    input  logic clk_50mhz,
    input  logic rstN,
    input  logic correct_pulse,
    output logic SERVO_PWM
);

    localparam int PWM_PERIOD    = 1_000_000;
    localparam int PULSE_CLOSED  =    50_000;
    localparam int PULSE_OPEN    =   100_000;
    localparam int OPEN_HOLD     = 150_000_000;

    logic cp_meta, cp_sync, cp_d;

    always_ff @(posedge clk_50mhz or negedge rstN) begin
        if (!rstN) begin
            cp_meta <= 1'b0;
            cp_sync <= 1'b0;
            cp_d    <= 1'b0;
        end else begin
            cp_meta <= correct_pulse;
            cp_sync <= cp_meta;
            cp_d    <= cp_sync;
        end
    end

    wire cp_rise = cp_sync & ~cp_d;

    logic        position;
    logic [27:0] hold_cnt;

    always_ff @(posedge clk_50mhz or negedge rstN) begin
        if (!rstN) begin
            position <= 1'b0;
            hold_cnt <= 28'd0;
        end
        else if (cp_rise) begin
            position <= 1'b1;
            hold_cnt <= OPEN_HOLD[27:0];
        end
        else if (hold_cnt != 28'd0) begin
            hold_cnt <= hold_cnt - 28'd1;
            if (hold_cnt == 28'd1)
                position <= 1'b0;
        end
    end

    logic [19:0] pwm_cnt;
    logic [19:0] pulse_width;

    assign pulse_width = position ? PULSE_OPEN[19:0] : PULSE_CLOSED[19:0];

    always_ff @(posedge clk_50mhz or negedge rstN) begin
        if (!rstN)
            pwm_cnt <= 20'd0;
        else if (pwm_cnt + 20'd1 >= PWM_PERIOD[19:0])
            pwm_cnt <= 20'd0;
        else
            pwm_cnt <= pwm_cnt + 20'd1;
    end

    assign SERVO_PWM = (pwm_cnt < pulse_width);

endmodule
