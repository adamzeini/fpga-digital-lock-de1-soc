module pass_check (
    input  logic clk,
    input  logic rstN,
    input  logic reset,
    input  logic enter_p,
    input  logic check,
    input  logic error_left,
    output logic y,
    output logic start,
    output logic clr,
    output logic locked,
    output logic err,
    output logic in_login,
    output logic [2:0] tries_left,
    output logic correct_pulse,
    output logic wrong_pulse
);

    typedef enum logic [3:0] {
        s_default,
        s_correct_1,
        s_correct_2,
        s_correct_3,
        s_login,
        s_wrong,
        s_error,
        s_locked
    } state_t;

    state_t      s_reg,       s_next;
    logic [2:0]  pos_reg,     pos_next;
    logic [2:0]  tries_reg,   tries_next;
    logic [11:0] blink_cnt,   blink_cnt_next;

    always_ff @(posedge clk or negedge rstN) begin
        if (!rstN) begin
            s_reg     <= s_default;
            pos_reg   <= '0;
            tries_reg <= '0;
            blink_cnt <= '0;
        end else begin
            s_reg     <= s_next;
            pos_reg   <= pos_next;
            tries_reg <= tries_next;
            blink_cnt <= blink_cnt_next;
        end
    end

    always_comb begin
        s_next         = s_reg;
        pos_next       = pos_reg;
        tries_next     = tries_reg;
        blink_cnt_next = '0;
        y              = '0;
        start          = '0;
        clr            = '0;

        case (s_reg)

            s_default: begin
                start = (tries_reg != '0) && !enter_p;
                if (reset) begin
                    tries_next = '0;
                    clr        = '1;
                end else if ((tries_reg != '0) && error_left) begin
                    tries_next = '0;
                    clr        = '1;
                end else if (enter_p) begin
                    pos_next = 3'd1;
                    if (check) s_next = s_correct_1;
                    else       s_next = s_wrong;
                end
            end

            s_correct_1: begin
                start = '1;
                if (error_left) begin
                    s_next     = s_default;
                    pos_next   = '0;
                    tries_next = '0;
                    clr        = '1;
                end else if (enter_p) begin
                    pos_next = 3'd2;
                    if (check) s_next = s_correct_2;
                    else       s_next = s_wrong;
                end
            end

            s_correct_2: begin
                start = '1;
                if (error_left) begin
                    s_next     = s_default;
                    pos_next   = '0;
                    tries_next = '0;
                    clr        = '1;
                end else if (enter_p) begin
                    pos_next = 3'd3;
                    if (check) s_next = s_correct_3;
                    else       s_next = s_wrong;
                end
            end

            s_correct_3: begin
                start = '1;
                if (error_left) begin
                    s_next     = s_default;
                    pos_next   = '0;
                    tries_next = '0;
                    clr        = '1;
                end else if (enter_p) begin
                    pos_next = 3'd4;
                    if (check) s_next = s_login;
                    else       s_next = s_wrong;
                end
            end

            s_login: begin
                y              = blink_cnt[8];
                blink_cnt_next = blink_cnt + 12'd1;
                if (reset || blink_cnt >= 12'd3000) begin
                    s_next         = s_default;
                    pos_next       = '0;
                    tries_next     = '0;
                    clr            = '1;
                    blink_cnt_next = '0;
                end
            end

            s_wrong: begin
                start = '1;
                if (error_left) begin
                    s_next     = s_default;
                    pos_next   = '0;
                    tries_next = '0;
                    clr        = '1;
                end else if (pos_reg == 3'd4) begin
                    s_next   = s_error;
                    pos_next = '0;
                end else if (enter_p) begin
                    if (pos_reg == 3'd3) begin
                        s_next   = s_error;
                        pos_next = '0;
                    end else begin
                        pos_next = pos_reg + 3'd1;
                    end
                end
            end

            s_error: begin
                tries_next = tries_reg + 3'd1;
                clr        = '1;
                if (tries_next >= 3'd4) begin
                    s_next = s_locked;
                end else begin
                    s_next   = s_default;
                    pos_next = '0;
                end
            end

            s_locked: begin
                if (reset) begin
                    s_next     = s_default;
                    pos_next   = '0;
                    tries_next = '0;
                    clr        = '1;
                end
            end

            default: s_next = s_default;

        endcase
    end

    assign locked   = (s_reg == s_locked);
    assign in_login = (s_reg == s_login);
    assign tries_left = (tries_reg >= 3'd4) ? 3'd0 : (3'd4 - tries_reg);

    logic correct_pulse_r, wrong_pulse_r;

    always_ff @(posedge clk or negedge rstN) begin
        if (!rstN) begin
            correct_pulse_r <= 1'b0;
            wrong_pulse_r   <= 1'b0;
        end else begin
            correct_pulse_r <= (s_reg != s_login) && (s_next == s_login);
            wrong_pulse_r   <= (s_reg != s_error) && (s_next == s_error);
        end
    end

    assign correct_pulse = correct_pulse_r;
    assign wrong_pulse   = wrong_pulse_r;

    logic [11:0] err_hold;

    always_ff @(posedge clk or negedge rstN) begin
        if (!rstN)
            err_hold <= '0;
        else if (reset)
            err_hold <= '0;
        else if (wrong_pulse_r)
            err_hold <= 12'd2000;
        else if (err_hold != '0)
            err_hold <= err_hold - 12'd1;
    end

    assign err = (err_hold != '0);

endmodule
