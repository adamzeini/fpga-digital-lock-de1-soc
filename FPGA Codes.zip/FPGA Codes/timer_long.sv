module timer_long (
    input  logic clk,
    input  logic rstN,
    input  logic start,
    output logic error_left
);

    localparam logic [17:0] TIMEOUT_MS = 18'd252000;

    logic [17:0] t_reg, t_next;

    always_ff @(posedge clk or negedge rstN) begin
        if (!rstN)
            t_reg <= '0;
        else
            t_reg <= t_next;
    end

    assign t_next     = start ? ((t_reg >= TIMEOUT_MS) ? t_reg : (t_reg + 18'd1)) : '0;
    assign error_left = (t_reg >= TIMEOUT_MS) ? '1 : '0;

endmodule
