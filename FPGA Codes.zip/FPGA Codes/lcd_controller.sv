module lcd_controller (
    input  logic       clk,
    input  logic       rstN,
    input  logic [3:0] sys_state,
    input  logic [2:0] tries_left,

    output logic       LCD_RS,
    output logic       LCD_RW,
    output logic       LCD_E,
    output logic [3:0] LCD_D
);

    localparam logic [3:0] ST_WELCOME      = 4'd0;
    localparam logic [3:0] ST_SUPERVISOR   = 4'd1;
    localparam logic [3:0] ST_WRONG        = 4'd2;
    localparam logic [3:0] ST_LOCKED       = 4'd3;
    localparam logic [3:0] ST_CORRECT      = 4'd4;
    localparam logic [3:0] ST_CHANGE_AUTH  = 4'd5;
    localparam logic [3:0] ST_CHANGE_NEW   = 4'd6;
    localparam logic [3:0] ST_CHANGE_DONE  = 4'd7;
    localparam logic [3:0] ST_CHANGE_CONFIRM  = 4'd8;
    localparam logic [3:0] ST_CHANGE_MISMATCH = 4'd9;

    function automatic logic [127:0] line1_msg(input logic [3:0] s);
        case (s)
            ST_WELCOME:     line1_msg = "  Lock System   ";
            ST_SUPERVISOR:  line1_msg = "Supervisor Mode ";
            ST_WRONG:       line1_msg = "Wrong Password! ";
            ST_LOCKED:      line1_msg = " SYSTEM LOCKED  ";
            ST_CORRECT:     line1_msg = "Access Granted! ";
            ST_CHANGE_AUTH: line1_msg = "Change Password ";
            ST_CHANGE_NEW:  line1_msg = "  New Password  ";
            ST_CHANGE_CONFIRM:  line1_msg = "Confirm Password";
            ST_CHANGE_MISMATCH: line1_msg = "Passwords Differ";
            ST_CHANGE_DONE: line1_msg = "Password Changed";
            default:        line1_msg = "                ";
        endcase
    endfunction

    function automatic logic [127:0] line2_msg(
        input logic [3:0] s,
        input logic [2:0] tries
    );
        case (s)
            ST_WELCOME:     line2_msg = " Enter Password ";
            ST_SUPERVISOR:  line2_msg = " Enter Password ";
            ST_WRONG: begin
                case (tries)
                    3'd3:    line2_msg = " 3 Tries Left   ";
                    3'd2:    line2_msg = " 2 Tries Left   ";
                    3'd1:    line2_msg = " 1 Try Left     ";
                    default: line2_msg = " No Tries Left  ";
                endcase
            end
            ST_LOCKED:      line2_msg = "Press Sup. Reset";
            ST_CORRECT:     line2_msg = "                ";
            ST_CHANGE_AUTH: line2_msg = "Enter Super Pwd ";
            ST_CHANGE_NEW:  line2_msg = " First 4 Digits ";
            ST_CHANGE_CONFIRM:  line2_msg = " Repeat 4 Digits";
            ST_CHANGE_MISMATCH: line2_msg = "   Try Again    ";
            ST_CHANGE_DONE: line2_msg = "    Success!    ";
            default:        line2_msg = "                ";
        endcase
    endfunction

    function automatic logic [7:0] char_at(
        input logic [127:0] msg,
        input logic [5:0]   col
    );
        char_at = msg[(15 - col[3:0])*8 +: 8];
    endfunction

    typedef enum logic [3:0] {
        SB_IDLE,
        SB_HI_SET,
        SB_HI_E1,
        SB_HI_E0,
        SB_LO_SET,
        SB_LO_E1,
        SB_LO_E0,
        SB_WAIT
    } sb_t;

    sb_t        sb;
    logic [9:0] sb_wait;
    logic [9:0] sb_wait_max;
    logic       sb_is_byte;
    logic [7:0] sb_data;
    logic       sb_rs;
    logic       sb_start;
    logic       sb_done;
    assign sb_done = (sb == SB_IDLE) && !sb_start;

    always_comb begin
        LCD_RS = 1'b0;
        LCD_RW = 1'b0;
        LCD_E  = 1'b0;
        LCD_D  = 4'h0;

        unique case (sb)
            SB_HI_SET, SB_HI_E1, SB_HI_E0: begin
                LCD_RS = sb_rs;
                LCD_D  = sb_data[7:4];
                LCD_E  = (sb == SB_HI_E1);
            end
            SB_LO_SET, SB_LO_E1, SB_LO_E0: begin
                LCD_RS = sb_rs;
                LCD_D  = sb_data[3:0];
                LCD_E  = (sb == SB_LO_E1);
            end
            SB_WAIT: begin
                LCD_RS = sb_rs;
                LCD_D  = sb_is_byte ? sb_data[3:0] : sb_data[7:4];
                LCD_E  = 1'b0;
            end
            default: ;
        endcase
    end

    always_ff @(posedge clk or negedge rstN) begin
        if (!rstN) begin
            sb      <= SB_IDLE;
            sb_wait <= 10'd0;
        end else begin
            unique case (sb)
                SB_IDLE: begin
                    if (sb_start) sb <= SB_HI_SET;
                end
                SB_HI_SET: sb <= SB_HI_E1;
                SB_HI_E1:  sb <= SB_HI_E0;
                SB_HI_E0:  sb <= sb_is_byte ? SB_LO_SET : SB_WAIT;
                SB_LO_SET: sb <= SB_LO_E1;
                SB_LO_E1:  sb <= SB_LO_E0;
                SB_LO_E0:  sb <= SB_WAIT;
                SB_WAIT: begin
                    if (sb_wait + 10'd1 >= sb_wait_max) begin
                        sb      <= SB_IDLE;
                        sb_wait <= 10'd0;
                    end else begin
                        sb_wait <= sb_wait + 10'd1;
                    end
                end
                default: sb <= SB_IDLE;
            endcase
        end
    end

    typedef enum logic [2:0] {
        M_PWR_WAIT,
        M_INIT,
        M_IDLE,
        M_REFRESH
    } master_t;

    master_t       master;
    logic [9:0]    pwr_cnt;
    logic [3:0]    init_idx;
    logic [5:0]    ref_idx;
    logic [3:0]    last_state;
    logic [2:0]    last_tries;
    logic          step_sent;

    logic [127:0]  refresh_l1, refresh_l2;

    function automatic logic [7:0] init_data(input logic [3:0] step);
        case (step)
            4'd0:  init_data = 8'h30;
            4'd1:  init_data = 8'h30;
            4'd2:  init_data = 8'h30;
            4'd3:  init_data = 8'h20;
            4'd4:  init_data = 8'h28;
            4'd5:  init_data = 8'h08;
            4'd6:  init_data = 8'h01;
            4'd7:  init_data = 8'h06;
            4'd8:  init_data = 8'h0C;
            default: init_data = 8'h00;
        endcase
    endfunction

    function automatic logic init_is_byte(input logic [3:0] step);
        init_is_byte = (step >= 4'd4);
    endfunction

    function automatic logic [9:0] init_wait(input logic [3:0] step);
        case (step)
            4'd0:    init_wait = 10'd5;
            4'd6:    init_wait = 10'd3;
            default: init_wait = 10'd1;
        endcase
    endfunction

    localparam logic [3:0] INIT_LAST = 4'd8;

    function automatic logic [7:0] ref_data(
        input logic [5:0]   step,
        input logic [127:0] l1,
        input logic [127:0] l2
    );
        if      (step == 6'd0)   ref_data = 8'h80;
        else if (step <= 6'd16)  ref_data = char_at(l1, step - 6'd1);
        else if (step == 6'd17)  ref_data = 8'hC0;
        else                     ref_data = char_at(l2, step - 6'd18);
    endfunction

    function automatic logic ref_is_cmd(input logic [5:0] step);
        ref_is_cmd = (step == 6'd0) || (step == 6'd17);
    endfunction

    localparam logic [5:0] REF_LAST = 6'd33;

    always_ff @(posedge clk or negedge rstN) begin
        if (!rstN) begin
            master      <= M_PWR_WAIT;
            pwr_cnt     <= 10'd0;
            init_idx    <= 4'd0;
            ref_idx     <= 6'd0;
            last_state  <= 4'hF;
            last_tries  <= 3'h7;
            refresh_l1  <= '0;
            refresh_l2  <= '0;
            sb_start    <= 1'b0;
            sb_data     <= 8'h00;
            sb_rs       <= 1'b0;
            sb_is_byte  <= 1'b0;
            sb_wait_max <= 10'd1;
            step_sent   <= 1'b0;
        end else begin
            sb_start <= 1'b0;

            unique case (master)

                M_PWR_WAIT: begin
                    if (pwr_cnt + 10'd1 >= 10'd200) begin
                        master    <= M_INIT;
                        init_idx  <= 4'd0;
                        step_sent <= 1'b0;
                        pwr_cnt   <= 10'd0;
                    end else begin
                        pwr_cnt  <= pwr_cnt + 10'd1;
                    end
                end

                M_INIT: begin
                    if (sb_done && step_sent) begin
                        step_sent <= 1'b0;
                        if (init_idx == INIT_LAST) begin
                            master   <= M_IDLE;
                        end else begin
                            init_idx <= init_idx + 4'd1;
                        end
                    end else if (sb == SB_IDLE && !sb_start && !step_sent) begin
                        sb_data     <= init_data(init_idx);
                        sb_is_byte  <= init_is_byte(init_idx);
                        sb_rs       <= 1'b0;
                        sb_wait_max <= init_wait(init_idx);
                        sb_start    <= 1'b1;
                        step_sent   <= 1'b1;
                    end
                end

                M_IDLE: begin
                    if ((sys_state != last_state) || (tries_left != last_tries)) begin
                        refresh_l1 <= line1_msg(sys_state);
                        refresh_l2 <= line2_msg(sys_state, tries_left);
                        last_state <= sys_state;
                        last_tries <= tries_left;
                        ref_idx    <= 6'd0;
                        step_sent  <= 1'b0;
                        master     <= M_REFRESH;
                    end
                end

                M_REFRESH: begin
                    if (sb_done && step_sent) begin
                        step_sent <= 1'b0;
                        if (ref_idx == REF_LAST) begin
                            master <= M_IDLE;
                        end else begin
                            ref_idx <= ref_idx + 6'd1;
                        end
                    end else if (sb == SB_IDLE && !sb_start && !step_sent) begin
                        sb_data     <= ref_data(ref_idx, refresh_l1, refresh_l2);
                        sb_is_byte  <= 1'b1;
                        sb_rs       <= ~ref_is_cmd(ref_idx);
                        sb_wait_max <= ref_is_cmd(ref_idx) ? 10'd2 : 10'd1;
                        sb_start    <= 1'b1;
                        step_sent   <= 1'b1;
                    end
                end

                default: master <= M_PWR_WAIT;
            endcase
        end
    end

endmodule
